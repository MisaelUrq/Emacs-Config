# cepl.skitter

Plumbing to use skitter.sdl2 with cepl.

Currently provides only cepl.skitter.sdl2, more systems will be added when more hosts for cepl are added
